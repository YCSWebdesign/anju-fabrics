export default
{

    
        BANNER_LOGO: require("../assets/logo.webp"),
        BANNER_ONE:  require("../assets/bannerone.webp"),
        BANNER_TWO:  require("../assets/bannertwo.webp"),
        BANNER_THREE:  require("../assets/bannerthree.webp"),
        
     //ABOUT
        STITCH:  require("../assets/stitch.webp"),
        UPSCALE: require("../assets/upscale.webp"),
        QUALITY: require("../assets/quality.webp"),
        GLOBE: require("../assets/globe.webp"),
       
      //product
      
        PRODUCT1: require("../assets/product1.webp"),
        PRODUCT2: require("../assets/product2.webp"),
        PRODUCT3: require("../assets/product3.webp"),
        PRODUCT4: require("../assets/product4.webp"),
        PRODUCT5: require("../assets/product5.webp"),
        PRODUCT6: require("../assets/product6.webp"),
        PRODUCT7: require("../assets/product7.webp"),
        PRODUCT8: require("../assets/product8.webp"),
        
        // gallery

        GALLERY1: require("../assets/gallery1.webp"),
        GALLERY2: require("../assets/gallery2.webp"),
        GALLERY3: require("../assets/gallery3.webp"),
        GALLERY4: require("../assets/gallery4.webp"),
        GALLERY5: require("../assets/gallery5.webp"),
        GALLERY6: require("../assets/gallery6.webp"),
        GALLERY7: require("../assets/gallery7.webp"),
        GALLERY8: require("../assets/gallery8.webp"),
        GALLERY9: require("../assets/gallery9.webp"),
        GALLERY10: require("../assets/gallery10.webp"),
        GALLERY11: require("../assets/gallery11.webp"),
        GALLERY12: require("../assets/gallery12.webp"),
        GALLERY13: require("../assets/gallery13.webp"),
        GALLERY10: require("../assets/gallery10.webp"),
         GALLERY15: require("../assets/gallery15.webp"),
        //  GALLERY16: require("../assets/gallery16.webp"),                     
        //  GALLERY19: require("../assets/gallery19.webp"),
        //  GALLERY21: require("../assets/gallery21.webp"),
        // GALLERY22: require("../assets/gallery22.webp"),
        //  GALLERY23: require("../assets/gallery23.webp"),
        // GALLERY24: require("../assets/gallery24.webp"),
        // GALLERY25: require("../assets/gallery25.webp"),
        // GALLERY26: require("../assets/gallery26.webp"),
        // GALLERY27: require("../assets/gallery27.webp"),
        // GALLERY28: require("../assets/gallery28.webp"),
      



}